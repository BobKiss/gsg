<?php
//require all routes
require_once get_template_directory() . '/inc/ajax/get-flat-tab-content.php';
require_once get_template_directory() . '/inc/ajax/add-flat-to-cart.php';
